package com.avsinsight.community.web.dto;

public class PersonDtoRq {

    private String name;
    private String surname;
    private String thirdname;
    private String email;
    private String pass;

    public PersonDtoRq(String name, String surname, String thirdname, String email, String pass) {
        this.name = name;
        this.surname = surname;
        this.thirdname = thirdname;
        this.email = email;
        this.pass = pass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getThirdname() {
        return thirdname;
    }

    public void setThirdname(String thirdname) {
        this.thirdname = thirdname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
