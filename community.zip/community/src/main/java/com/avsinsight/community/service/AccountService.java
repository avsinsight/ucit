package com.avsinsight.community.service;

import com.avsinsight.community.web.dto.PersonDtoRq;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AccountService {

    public String create(PersonDtoRq personDtoRq){

        return UUID.randomUUID().toString();
    }


}
