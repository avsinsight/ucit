package com.avsinsight.community.web.controller;

import com.avsinsight.community.service.AccountService;
import com.avsinsight.community.web.dto.PersonDtoRq;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class ApiRestController {

    private AccountService accountService;

    @Autowired
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping("/create_account")
    public ModelAndView createAccount(
            @RequestParam(name="email") String email,
            @RequestParam(name="name") String name,
            @RequestParam(name="surname") String surname,
            @RequestParam(name="fathername") String fathername,
            @RequestParam(name="pass") String pass) {

        ModelAndView modelAndView = new ModelAndView("/index");
        modelAndView.addObject("session_key",
                accountService.create(
                        new PersonDtoRq(name, surname, fathername, email, pass))
        );

        return modelAndView;
    }
}
